export const runtime = 'nodejs';

export { GET, POST } from '../../../../lib/auth';
