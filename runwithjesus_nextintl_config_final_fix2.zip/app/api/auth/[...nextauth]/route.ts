export { GET, POST } from '../../../../lib/auth';
